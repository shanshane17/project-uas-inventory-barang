<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "stockbarang";
$koneksi = mysqli_connect($host, $user, $password, $database);
?>